<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once("includes/config.php");

class Home extends CI_controller{
	public function __construct()
    {
            parent::__construct();
            $this->error = "";
            
            //Load CI url helper for use later.(base_url()).
            $this->load->helper("url");
    }

	public function index()
	{
		//Load home page.
		$this->load->view("header");
		$this->load->view("nav");
		$this->load->view("home");
		$this->load->view("footer");
	}

	//Get headline news
	private function get_headlines()
	{

	}

	//Get user preferencial news
	private function get_user_news($user_id)
	{

	}

	// Get news by category
	private function get_news_category($category)
	{

	}

	//Get breaking news
	private function get_breaking_news()
	{

	}
}


?>