  <style type="text/css">
    .content{
      min-height: 450px;
    }
  </style>
  <div class="content">
    <h2>Oops! </h2>
    <h3>Page is under construction</h3>
  </div>