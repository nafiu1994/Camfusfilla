<footer>
    <div class="container">
      </div>
      <div class="row">
        <div class="col-lg-4">
            <a href="CampusFila.com"><img class="img-responsive" src="<?=base_url("assets/img/logo.png")?>" alt=""></a>
            
        </div>
        <div class="col-lg-4">
            <h4>News Categories</h4>
            <div>
              <ul class="arrow">
                  <li><a href="#">News</a></li>
                  <li><a href="#">Fila</a></li>
                  <li><a href="#">Business</a></li>
                  <li><a href="#">Entertainment</a></li>
                  <li><a href="#">Sports</a></li>
                  <li><a href="#">Notice Board</a></li>
              </ul>
          </div>
        </div>
        <div class="col-lg-4">
          <h3>Follow Us</h3>
          <div class="social-links">
                <a class="facebook" href="#"></a>
                <a class="twitter" href="#"></a>
                <a class="youtube" href="#"></a>
            </div>
        </div>
      </div> <!-- end row -->
       
       <div class="row" style="padding-top:10px;border-top:1px solid #999">
            <div class="col-lg-7">

                <span>Copyright © <?=date("Y");?>&nbsp; - <span style="color: #2196F3;font-size: 20px">Campus<span style="color:#4caf50">Fila</sapn></span> </span>
            </div>
            <div class="col-lg-1"></div>
            <div class="col-lg-4">
              Powered By Lawal IT Solutions Ltd
            </div>
        </div> <!-- end row -->
    </div> <!-- end container -->
</footer>

</div>

</body>
</html>