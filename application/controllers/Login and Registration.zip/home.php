<link rel="stylesheet" type="text/css" href="<?=base_url("assets/css/home-style.css")?>">
<div class="content">
    <link href="<?=base_url("assets/font-awesome/css/font-awesome.min.css")?>" rel="stylesheet" type="text/css">
    <div id="slideshow" class="breaking-news">
      <span class="breaking-news-title">BREAKING NEWS</span>
       <div>
         <a href="" title="13 Bought Our Theme">13,000+ People Have Bought Our Theme</a>
       </div>
       <div>
         <a href="" title="13 Bought Our Theme">Top Search Engine Optimization Strategies!</a>
       </div>
       <div>
         <a href="" title="Used Car Dealer Sales Tricks Exposed">Used Car Dealer Sales Tricks Exposed</a>
       </div>
    <script type="text/javascript">
      $("#slideshow > div:gt(0)").hide();
      setInterval(function() {
        $('#slideshow > div:first')
          .fadeOut(1000)
          .next()
          .fadeIn(1000)
          .end()
          .appendTo('#slideshow');
      }, 3000);
    </script>
</div>
      <div class="container">
      <div class="row top-stories"> 
      
        <!-- PORTFOLIO IMAGE 1 -->
        <div class="col-md-6 col-xs-6">
            <div class="grid mask">
            <div>
              <a href="article/view/4"><img class="img-responsive" src="<?=base_url("assets/img/003.jpg")?>" alt="IMAGE"></a>
              <div class="overlay">
                <h6 class="time" ><span class="fa fa-clock-o"></span> Oct, 2017</h6>
                <h2 class="h-title">ECG apologizes to students</h2>
                <h3 class="h-sub-title">ECG boss has issued a apology to the University of Ghana students who are currently witting their.....</h3>
              </div><!-- /figcaption -->
            </div><!-- /figure -->
            </div><!-- /grid-mask -->
        </div><!-- /col -->

        <!-- PORTFOLIO IMAGE 2 -->
        <div class="col-md-6 col-xs-6">
            <div class="grid mask">
            <figure>
              <a href=""><img class="img-responsive" src="<?=base_url("assets/img/004.jpg")?>" alt=""></a>
              <figcaption class="overlay">
                <h6 class="time"><span class="fa fa-clock-o"></span> Oct, 2017</h6>
                <h5>TEWU On Strike</h5>
                <p>ECG boss has issued a apology to the University of Ghana students who are currently witting their.....</p>
                <a data-toggle="modal" href="#myModal" class="btn btn-primary btn-sm">Read more</a>
              </figcaption><!-- /figcaption -->
            </figure><!-- /figure -->
            </div><!-- /grid-mask -->
        </div><!-- /col -->
        
        <!-- PORTFOLIO IMAGE 3 -->
        
      </div><!-- /row -->

        <!-- PORTFOLIO IMAGE 4 -->
      <div class="row top-stories"> 
        <div class="col-md-4 col-xs-4">
            <div class="grid mask">
            <figure>
              <a href=""><img class="img-responsive" src="<?=base_url("assets/img/006.jpg")?>" alt=""></a>
              <figcaption class="overlay">
                <h6 class="time"><span class="fa fa-clock-o"></span> Oct, 2017</h6>
                <h5 class="title">ECG apologizes to students</h5>
                <p>ECG boss has issued a apology to the University of Ghana students who are currently witting their.....</p>
                <a data-toggle="modal" href="" class="btn btn-primary btn-sm">Read more</a>
              </figcaption><!-- /figcaption -->
            </figure><!-- /figure -->
            </div><!-- /grid-mask -->
        </div><!-- /col -->
        
        <!-- PORTFOLIO IMAGE 5 -->
        <div class="col-md-4 col-xs-4">
            <div class="grid mask">
            <figure>
              <a href=""><img class="img-responsive" src="<?=base_url("assets/img/004.jpg")?>" alt=""></a>
              <figcaption class="overlay">
                <h6 class="time"><span class="fa fa-clock-o"></span> Oct, 2017</h6>
                <h5 class="title">ECG apologizes to students</h5>
                <p>ECG boss has issued a apology to the University of Ghana students who are currently witting their.....</p>
                <a data-toggle="modal" href="" class="btn btn-primary btn-sm">Read more</a>
              </figcaption><!-- /figcaption -->
            </figure><!-- /figure -->
            </div><!-- /grid-mask -->
        </div><!-- /col -->
        
        <!-- PORTFOLIO IMAGE 6 -->
        <div class="col-md-4 col-xs-4">
            <div class="grid mask">
            <figure>
              <a href=""><img class="img-responsive" src="<?=base_url("assets/img/002.jpg")?>" alt=""></a>
              <figcaption class="overlay">
                <h6 class="time"><span class="fa fa-clock-o"></span> Oct, 2017</h6>
                <h5 class="title">ECG apologizes to students</h5>
                <p>ECG boss has issued a apology to the University of Ghana students who are currently witting their.....</p>
                <a data-toggle="modal" href="" class="btn btn-primary btn-sm">Read more</a>
              </figcaption><!-- /figcaption -->
            </figure><!-- /figure -->
            </div><!-- /grid-mask -->
        </div><!-- /col -->
      </div><!-- /row -->
      <br>
<div class="row trends" style="padding: 0px">
  <div class="col-md-8 col-sm-12 first-trend">
  <h4>My News</h4><div class="stripe-line"></div>
    <div class="row outer-trends">
      <div class="col-lg-6 col-xs-6 first-news">
        <img src="<?=base_url("assets/img/005.jpg")?>" alt=" picture" class="thumbnail-pic" >
        <h6 class="post-title" style="font-size: 20px; line-height: 26px;">Title</h6>
        <p>The government promisghes a reform Cras sit amet nibh libero, in gravida nulla. Nulla vel...</p>
        <a class="more-link" href="https://themes.tielabs.com/sahifa/2015/01/30/13000-people-have-bought-our-theme/">Read More »</a>
      </div>
      <div class="col-lg-6">
      <div class="row inner-trends">
        <div class="col-xs-4"><a href=""><img class="img-responsive" src="<?=base_url("assets/img/004.jpg")?>" alt=""></a></div>
        <div class="col-xs-8">
          <p class="post-title">The hearing is tomorrow bro</p>
          <h6 class="time" ><span class="fa fa-clock-o"></span> Oct, 2017</h6>
        </div>
      </div>
      <div class="row inner-trends">
        <div class="col-xs-4"><a href=""><img class="img-responsive" src="<?=base_url("assets/img/002.jpg")?>" alt=""></a></div>
        <div class="col-xs-8">
          <p class="post-title">The hearing is tomorrow bro</p>
          <h6 class="time" ><span class="fa fa-clock-o"></span> Oct, 2017</h6>
        </div>

      </div>
      <div class="row inner-trends">
        <div class="col-xs-4"><a href=""><img class="img-responsive" src="<?=base_url("assets/img/003.jpg")?>" alt=""></a></div>
        <div class="col-xs-8">
          <p class="post-title">The hearing is tomorrow bro</p>
          <h6 class="time" ><span class="fa fa-clock-o"></span> Oct, 2017</h6>
        </div>

      </div>
      <div class="row inner-trends">
        <div class="col-xs-4"><a href=""><img class="img-responsive" src="<?=base_url("assets/img/006.jpg")?>" alt=""></a></div>
        <div class="col-xs-8">
          <p class="post-title">The hearing is tomorrow bro</p>
          <h6 class="time" ><span class="fa fa-clock-o"></span> Oct, 2017</h6>
        </div>

      </div>
      </div> 
  </div>
  </div>
  <div class="col-md-4 col-sm-6 mid-col"></div>
    
  </div>
  <div class="row">
    <div class="col-md-4 col-sm-6" style="margin-right: 10px">
    <h4>Fila</h4><div class="stripe-line" sty=""></div>
    <div class="second-trend">
      <div class="row first-row-outer">
        <div class="col-lg-12 col-xs-6 col-md-12 col-sm-12">
          <img src="http://[::1]/campusfila/assets/img/006.jpg" alt="course picture" class="thumbnail-pic" style="vertical-align: middle">
        </div>
        <div class="caption">
          <h6 class="post-title">Imagine Losing 20 Pounds In 14 Days!</h6>
          <h6 class="time"><span class="fa fa-clock-o"></span> Oct, 2017</h6>
          <p>Don’t act so surprised, Your Highness. You weren’t on any mercy mission this time. Several …</p>
          <a class="more-link" href="">Read More »</a>
        </div>
      </div>
      <div class="row second-inner-trend">
        <div class="col-xs-4"><a href=""><img class="img-responsive" src="http://[::1]/campusfila/assets/img/004.jpg" alt=""></a></div>
        <div class="col-xs-8"><p>The hearing is tomorrow bro</p></div>
      </div>
      <div class="row second-inner-trend">
        <div class="col-xs-4"><a href=""><img class="img-responsive" src="http://[::1]/campusfila/assets/img/002.jpg" alt=""></a></div>
        <div class="col-xs-8"><p>The hearing is tomorrow bro</p></div>
      </div>
      <div class="row second-inner-trend">
        <div class="col-xs-4"><a href=""><img class="img-responsive" src="http://[::1]/campusfila/assets/img/003.jpg" alt=""></a></div>
        <div class="col-xs-8"><p>The hearing is tomorrow bro</p></div>
      </div>
    </div>
    </div>
    <div class="col-md-4 col-sm-6">
    <h4>Notice Board</h4><div class="stripe-line"></div>
    <div class="second-trend">
    <div class="row first-row-outer">
      <div class="col-lg-12 col-xs-6 col-md-12 col-sm-12">
        <img src="http://[::1]/campusfila/assets/img/004.jpg" alt="course picture" class="thumbnail-pic" style="vertical-align: middle">
      </div>
      <div class="caption">
        <h6 class="post-title">Used Car Dealer Sales Tricks Exposed</h6>
        <h6 class="time"><span class="fa fa-clock-o"></span> Oct, 2017</h6>
        <p>Don’t act so surprised, Your Highness. You weren’t on any mercy mission this time. Several …</p>
        <a class="more-link" href="">Read More »</a>
      </div>
    </div>
    <div class="row second-inner-trend">
      <div class="col-xs-4"><a href=""><img class="img-responsive" src="http://[::1]/campusfila/assets/img/004.jpg" alt=""></a></div>
      <div class="col-xs-8"><p>The hearing is tomorrow bro</p></div>
    </div>
    <div class="row second-inner-trend">
      <div class="col-xs-4"><a href=""><img class="img-responsive" src="http://[::1]/campusfila/assets/img/002.jpg" alt=""></a></div>
      <div class="col-xs-8"><p>The hearing is tomorrow bro</p></div>
    </div>
    <div class="row second-inner-trend">
      <div class="col-xs-4"><a href=""><img class="img-responsive" src="http://[::1]/campusfila/assets/img/003.jpg" alt=""></a></div>
      <div class="col-xs-8"><p>The hearing is tomorrow bro</p></div>
    </div>
  </div> 
</div>
</div>
  <div class="row">
    <div class="col-md-4 col-sm-6" style="margin-right: 10px">
    <h4>Sports</h4><div class="stripe-line" sty></div>
    <div class="second-trend">
      <div class="row first-row-outer">
        <div class="col-lg-12 col-xs-6 col-md-12 col-sm-12">
          <img src="<?=base_url("assets/img/006.jpg")?>" alt="course picture" class="thumbnail-pic" style="vertical-align: middle">
        </div>
        <div class="caption">
          <h6 class="post-title">Imagine Losing 20 Pounds In 14 Days!</h6>
          <h6 class="time" ><span class="fa fa-clock-o"></span> Oct, 2017</h6>
          <p>Don’t act so surprised, Your Highness. You weren’t on any mercy mission this time. Several …</p>
          <a class="more-link" href="">Read More »</a>
        </div>
      </div>
      <div class="row second-inner-trend">
        <div class="col-xs-4"><a href=""><img class="img-responsive" src="<?=base_url("assets/img/004.jpg")?>" alt=""></a></div>
        <div class="col-xs-8"><p>The hearing is tomorrow bro</p></div>
      </div>
      <div class="row second-inner-trend">
        <div class="col-xs-4"><a href=""><img class="img-responsive" src="<?=base_url("assets/img/002.jpg")?>" alt=""></a></div>
        <div class="col-xs-8"><p>The hearing is tomorrow bro</p></div>
      </div>
      <div class="row second-inner-trend">
        <div class="col-xs-4"><a href=""><img class="img-responsive" src="<?=base_url("assets/img/003.jpg")?>" alt=""></a></div>
        <div class="col-xs-8"><p>The hearing is tomorrow bro</p></div>
      </div>
    </div>
    </div>
    <div class="col-md-4 col-sm-6" >
    <h4>Entertainment</h4><div class="stripe-line"></div>
    <div class="second-trend">
    <div class="row first-row-outer">
      <div class="col-lg-12 col-xs-6 col-md-12 col-sm-12">
        <img src="<?=base_url("assets/img/004.jpg")?>" alt="course picture" class="thumbnail-pic" style="vertical-align: middle">
      </div>
      <div class="caption">
        <h6 class="post-title">Used Car Dealer Sales Tricks Exposed</h6>
        <h6 class="time" ><span class="fa fa-clock-o"></span> Oct, 2017</h6>
        <p>Don’t act so surprised, Your Highness. You weren’t on any mercy mission this time. Several …</p>
        <a class="more-link" href="">Read More »</a>
      </div>
    </div>
    <div class="row second-inner-trend">
      <div class="col-xs-4"><a href=""><img class="img-responsive" src="<?=base_url("assets/img/004.jpg")?>" alt=""></a></div>
      <div class="col-xs-8"><p>The hearing is tomorrow bro</p></div>
    </div>
    <div class="row second-inner-trend">
      <div class="col-xs-4"><a href=""><img class="img-responsive" src="<?=base_url("assets/img/002.jpg")?>" alt=""></a></div>
      <div class="col-xs-8"><p>The hearing is tomorrow bro</p></div>
    </div>
    <div class="row second-inner-trend">
      <div class="col-xs-4"><a href=""><img class="img-responsive" src="<?=base_url("assets/img/003.jpg")?>" alt=""></a></div>
      <div class="col-xs-8"><p>The hearing is tomorrow bro</p></div>
    </div>
  </div> 
</div>
</div>
<div class="row trends">
<div class="col-md-8 carousel-block">
<h4>More Stories</h4>
<div id="myCarousel" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
    <h4>Business</h4><div class="stripe-line"></div>
      <div class="row">
        <div class="col-lg-4 col-xs-6 col-md-4 col-sm-4 carousel-item-inner">
          <img src="http://[::1]/campusfila/assets/img/006.jpg" alt="course picture" class="thumbnail-pic" style="vertical-align: middle">
          <div class="caption">
            <h6 class="post-title">Imagine Losing 20 Pounds In 14 Days!</h6>
            <h6 class="time"><span class="fa fa-clock-o"></span> Oct, 2017</h6>
          </div>
        </div> 
        <div class="col-lg-4 col-xs-6 col-md-4 col-sm-4 carousel-item-inner">
          <img src="http://[::1]/campusfila/assets/img/006.jpg" alt="course picture" class="thumbnail-pic" style="vertical-align: middle">
          <div class="caption">
            <h6 class="post-title">Imagine Losing 20 Pounds In 14 Days!</h6>
            <h6 class="time"><span class="fa fa-clock-o"></span> Oct, 2017</h6>
          </div>
        </div>
        <div class="col-lg-4 col-xs-6 col-md-4 col-sm-4 carousel-item-inner">
          <img src="http://[::1]/campusfila/assets/img/006.jpg" alt="course picture" class="thumbnail-pic" style="vertical-align: middle">
          <div class="caption">
            <h6 class="post-title">Imagine Losing 20 Pounds In 14 Days!</h6>
            <h6 class="time"><span class="fa fa-clock-o"></span> Oct, 2017</h6>
          </div>
        </div>
      </div>
    </div>

    <div class="item">
    <h4>Other News</h4><div class="stripe-line"></div>
      <div class="row">
        <div class="col-lg-4 col-xs-6 col-md-4 col-sm-4 carousel-item-inner">
          <img src="http://[::1]/campusfila/assets/img/006.jpg" alt="course picture" class="thumbnail-pic" style="vertical-align: middle">
          <div class="caption">
            <h6 class="post-title">Imagine Losing 20 Pounds In 14 Days!</h6>
            <h6 class="time"><span class="fa fa-clock-o"></span> Oct, 2017</h6>
          </div>
        </div> 
        <div class="col-lg-4 col-xs-6 col-md-4 col-sm-4 carousel-item-inner">
          <img src="http://[::1]/campusfila/assets/img/006.jpg" alt="course picture" class="thumbnail-pic" style="vertical-align: middle">
          <div class="caption">
            <h6 class="post-title"><a href="">New! A Stain Remover That Works Like Magic</a></h6>
            <h6 class="time"><span class="fa fa-clock-o"></span> Oct, 2017</h6>
          </div>
        </div>
        <div class="col-lg-4 col-xs-6 col-md-4 col-sm-4 carousel-item-inner">
          <img src="http://[::1]/campusfila/assets/img/006.jpg" alt="course picture" class="thumbnail-pic" style="vertical-align: middle">
          <div class="caption">
            <h6 class="post-title">Imagine Losing 20 Pounds In 14 Days!</h6>
            <h6 class="time"><span class="fa fa-clock-o"></span> Oct, 2017</h6>
          </div>
        </div>
      </div>
    </div>

  </div> 
  </div>
</div>
  
</div>
</div>
</div>