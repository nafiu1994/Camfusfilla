<!DOCTYPE html>
<html lang="en">
  <head>
    <title>CampusFila</title>
    <link href="<?=base_url("assets/css/bootstrap.min.css")?>" rel="stylesheet">
    <link rel="stylesheet" href="<?=base_url("assets/css/nav-footer.css")?>" />
    <link rel="stylesheet" href="<?=base_url("assets/css/style.css")?>" />
    <script type="text/javascript" src="<?=base_url("assets/js/jquery-1.11.1.min.js")?>"></script>
    <script type="text/javascript" src="<?=base_url("assets/js/bootstrap.min.js")?>"></script>
    <link rel="shortcut icon" href="<?=base_url("assets/img/logo-small.png")?>">
    <link rel="apple-touch-icon" href="<?=base_url("assets/img/logo-small.png")?>"> 
    <link rel="apple-touch-icon-precompsed" href="<?=base_url("assets/img/logo-small.png")?>"> 
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
</head>